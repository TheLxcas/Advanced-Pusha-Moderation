
const { green } = require("../configs/emojis.json");

module.exports = async (message) => {
  let data = await serverSettings.findOne({ guildID: message.guild.id });
  let tag = data.TAG;
  
  if (message.content.toLowerCase() === "tag" || message.content.toLowerCase() === "!tag" || message.content.toLowerCase() === ".tag") {
    message.react(green);
    message.lineReply(tag);
  }
};
module.exports.conf = {
  name: "message"
};
