const client = global.client;
;

const penals = require("../schemas/penals");
const {MessageEmbed} = require("discord.js")
module.exports = async () => {
  let data = await serverSettings.findOne({ guildID: message.guild.id });
//ETKİNLİK ROL ALMA
  client.ws.on('INTERACTION_CREATE', async interaction => {  
    let name = interaction.data.custom_id
    let GameMap = new Map([
        ["buttoncekilis",`${data.ÇEK}`],
        ["buttonetkinlik",`${data.ETK}`],

        ["buttonlgbt",`${data.LGBT}`],
        ["buttonsevgilimvar",`${data.SEVVAR}`],
        ["buttonsevgilimyok",`${data.SEVYOK}`],
        ["buttonsevgiliyapmiyorum",`${data.SEVYAPM}`],
        
        ["buttondcuye",`${data.DC}`],
        ["buttonvkuye",`${data.VK}`]

    ])
    let member = await client.guilds.cache.get(settings.guildID).members.fetch(interaction.member.user.id)
    if(!GameMap.has(name) || !member) return;
    let role = GameMap.get(name)
    let returnText;
    if(member.roles.cache.has(role)){
        await member.roles.remove(role)
        returnText = `Rol üzerinizden alındı`
    }else{
        await member.roles.add(role)
        returnText = `Rol üzerinize verildi`
      }
    client.api.interactions(interaction.id, interaction.token).callback.post({
        data: {
            type: 4,
            data: {
                content: returnText,
                flags: "64"}}})});

  client.guilds.cache.forEach(async (guild) => {
    const invites = await guild.fetchInvites();
    client.invites.set(guild.id, invites);
  });

  let botVoiceChannel = client.channels.cache.get(this.client.config.botses); 
  if (botVoiceChannel) 
  botVoiceChannel.join().then(e => {
    e.voice.setSelfDeaf(true);
    })
  .then(console.log(`Bot ses kanalına bağlandı!`)).catch(err => console.error("[HATA] Bot ses kanalına bağlanamadı!"));
  client.user.setPresence({ activity: { name: this.client.config.botDurum}, status: "idle" });
  
// Set username
client.user.setUsername('Executive')
  .then(user => console.log(`My new username is ${user.username}`))
  .catch(console.error);

client.guilds.cache.get(this.client.config.guildID).members.cache.filter(uye => uye.user.username.includes(data.TAG) && !uye.user.bot && !uye.roles.cache.has(data.BOOST) && (!uye.roles.cache.has(data.TEAM) || !uye.displayName.startsWith(data.TAG))).array().forEach((uye) => {
setTimeout(() => {
    if (data.TEAM) uye.roles.add(data.TEAM).catch({ })
}, 1000 * 60 * 60);
})

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

setInterval(() => { TagAlıncaKontrol(); }, 20 * 1000);
setInterval(() => { TagBırakanKontrol(); }, 15 * 1000);
setInterval(() => { RolsuzeKayitsizVerme(); }, 10 * 1000);

async function RolsuzeKayitsizVerme()  { // Rolü olmayanı kayıtsıza atma

const guild = client.guilds.cache.get(this.client.config.guildID);
let lucas = guild.members.cache.filter(m => m.roles.cache.filter(r => r.id !== guild.id).size == 0)
   lucas.forEach(r => {
   r.roles.add(data.UNREGISTER)
   })
 
};

async function TagAlıncaKontrol() { // Tag alınca tarama
const guild = this.client.guilds.cache.get(this.client.config.guildID)
const members = guild.members.cache.filter(member => member.user.username.includes(tag) && !member.roles.cache.has(data.JAIL) && !member.roles.cache.has(data.TEAM)).array().splice(0, 10)
for await (const member of members) {
 await member.roles.add(data.TEAM);
}
};

async function TagBırakanKontrol() { // Tagı olmayanın family rol çekme
const guild = this.client.guilds.cache.get(this.client.config.guildID)
const members = guild.members.cache.filter(member => !member.user.username.includes(data.TAG) && !member.user.bot && member.roles.cache.has(data.TEAM)).array().splice(0, 10)
for await (const member of members) {
 await member.roles.remove(data.TEAM)
}
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////s


setInterval(async () => {  
  const guild = client.guilds.cache.get(this.client.config.guildID);
  if (!guild) return;
  const finishedPenals = await penals.find({ guildID: guild.id, active: true, temp: true, finishDate: { $lte: Date.now() } });
  finishedPenals.forEach(async (x) => {
    const member = guild.members.cache.get(x.userID);
    if (!member) return;
    if (x.type === "CHAT-MUTE") {
      x.active = false;
      await x.save();
      await member.roles.remove(data.MUTED);
      client.channels.cache.get(client.channels.cache.find(x => x.name == "mute-log").id).send(new MessageEmbed().setColor("#2f3136").setDescription(`${member.toString()} adlı Kullanıcının **Chat Mute** süresi doldu`));
    }
    if (x.type === "TEMP-JAIL") {
      x.active = false;
      await x.save();
      await member.setRoles(data.UNREGISTER);
      client.channels.cache.get(client.channels.cache.find(x => x.name == "jail-log").id).send(new MessageEmbed().setColor("#2f3136").setDescription(`${member.toString()} üyesinin jaili, süresi bittiği için kaldırıldı!`));
    } 
    if (x.type === "TEMP-REKLAM") {
      x.active = false;
      await x.save();
      await member.setRoles(data.UNREGISTER);
      client.channels.cache.get(client.channels.cache.find(x => x.name == "jail-log").id).send(new MessageEmbed().setColor("#2f3136").setDescription(`${member.toString()} üyesinin reklami, süresi bittiği için kaldırıldı!`));
    } 
    if (x.type === "TEMP-BANNEDTAG") {
      x.active = false;
      await x.save();
      await member.setRoles(data.UNREGISTER);
      client.channels.cache.get(client.channels.cache.find(x => x.name == "yasaklı-tag-log").id).send(new MessageEmbed().setColor("#2f3136").setDescription(`${member.toString()} üyesi Yaşaklı Tag Kaldırdıgı İçin Kayıtsıza Atıldı`));
    } 
    if (x.type === "VOICE-MUTE") {
      if (member.voice.channelID) {
        x.removed = true;
        await x.save();
        if (member.voice.serverMute) member.voice.setMute(false);
      }
      x.active = false;
      await x.save();
      member.roles.remove(data.VMUTED);
      client.channels.cache.get(client.channels.cache.find(x => x.name == "vmute-log").id).send(new MessageEmbed().setColor("#2f3136").setDescription(`${member.toString()} adlı Kullanıcının **Ses Mute** süresi doldu`));
    }
  });

  const activePenals = await penals.find({ guildID: guild.id, active: true });
  activePenals.forEach(async (x) => {
    const member = guild.members.cache.get(x.userID);
    if (!member) return;
    if (x.type === "CHAT-MUTE" && !conf.chatMute.some((x) => member.roles.cache.has(x))) return member.roles.add(data.MUTED);
    if ((x.type === "JAIL" || x.type === "TEMP-JAIL") && !data.JAIL.some((x) => member.roles.cache.has(x))) return member.setRoles(data.JAIL);
    if ((x.type === "REKLAM" || x.type === "TEMP-REKLAM") && !data.JAIL.some((x) => member.roles.cache.has(x))) return member.setRoles(data.JAIL);
    if ((x.type === "BANNEDTAG" || x.type === "TEMP-BANNEDTAG") && !data.BANNEDTAG.some((x) => member.roles.cache.has(x))) return member.setRoles(data.BANNEDTAG);
    if (x.type === "VOICE-MUTE") {
      if (!data.VMUTED.some((x) => member.roles.cache.has(x))) member.roles.add(data.VMUTED);
      if (member.voice.channelID && !member.voice.serverMute) member.voice.setMute(true);
    }
  });
}, 1000 * 60);
};

module.exports.conf = {
  name: "ready",
};
