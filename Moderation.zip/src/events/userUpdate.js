const { MessageEmbed } = require("discord.js");
const regstats  = require("../schemas/registerStats");
const client = global.client;
const bannedTag = require("../schemas/bannedTag");
;

module.exports = async (oldUser, newUser) => {
  let server = await serverSettings.findOne({ guildID: message.guild.id });
    if (oldUser.bot || newUser.bot || (oldUser.username === newUser.username)) return;
    const guild = client.guilds.cache.get(this.client.config.guildID);
    if (!guild) return;
    const member = guild.members.cache.get(oldUser.id);
    if (!member) return;
    const channel = message.guild.channels.cache.get(client.channels.find(x => x.name == "tag-log").id);
    const kanal = guild.channels.cache.get(server.CHAT)
    const tagModedata = await regstats.findOne({ guildID: settings.guildID })
    if (oldUser.username.includes(server.TAG) && !newUser.username.includes(server.TAG)) {
      if (member.manageable && member.displayName.includes(server.TAG)) member.setNickname(member.displayName.replace(server.TAG, server.TAG2));
      if (tagModedata && tagModedata.tagMode) member.roles.set(server.UNREGISTER);
      else member.roles.remove(server.TEAM);
      if (!channel) return;
      const embed = new MessageEmbed()
        .setAuthor(member.displayName,  newUser.displayAvatarURL({ dynamic: true }))
        .setTitle("• Bir kullanıcı tag saldı!")
        .setColor("#2f3136")
        .setDescription(`
${member.toString()} kullanıcısı ${server.TAG} tagını saldığı için <@&${server.TEAM}> rolü alındı.
Aktif taglı sayısı: ${guild.members.cache.filter(x => x.user.username.includes(conf.tag)).size}
         `);
      channel.wsend(embed);
      } else if (!oldUser.username.includes(conf.tag) && newUser.username.includes(server.TAG)){
        if (member.manageable) member.setNickname(member.displayName.replace(server.TAG2, server.TAG));
      member.roles.add(server.TEAM);
      if (!channel) return;
      const embed = new MessageEmbed()
        .setAuthor(member.displayName, newUser.displayAvatarURL({ dynamic: true }))
        .setTitle("• Bir kullanıcı tag aldı!")
        .setColor("#2f3136")
        .setDescription(`
${member.toString()} kullanıcısı ${server.TAG} tagını aldığı için <@&${server.TEAM}> rolü verildi.
Aktif taglı sayısı: ${guild.members.cache.filter(x => x.user.username.includes(conf.tag)).size}
    `);
      channel.wsend(embed);
      kanal.wsend(new MessageEmbed().setColor("#2f3136").setDescription(`${member.toString()} üyesi ${server.TAG} tagımızı alarak ailemize katıldı! Ailemiz ${guild.members.cache.filter(x => x.user.username.includes(conf.tag)).size} kişi oldu!`)).then(x=>x.delete({timeout: 5000}))

    }
  
  
    await bannedTag.findOne({ guildID: guild.id }, async ( err, res) => {
      if (!res) return
    res.taglar.forEach(async x => {
      
   if (!oldUser.username.includes(x) && newUser.username.includes(x)) {
        !member.roles.cache.has(conf.boosterRolu) 
        await member.roles.set(server.BANTAG).catch();
        await member.setNickname('Yasaklı Tag');
       member.send(`${guild.name} adlı sunucumuza olan erişiminiz engellendi! Sunucumuzda yasaklı olan bir simgeyi (${x}) isminizde taşımanızdan dolayıdır. Sunucuya erişim sağlamak için simgeyi (${x}) isminizden çıkartmanız gerekmektedir.\n\nSimgeyi (${x}) isminizden kaldırmanıza rağmen üstünüzde halen Yasaklı Tag rolü varsa sunucudan gir çık yapabilirsiniz veya sağ tarafta bulunan yetkililer ile iletişim kurabilirsiniz. **-Yönetim**\n\n__Sunucu Tagımız__\n**${server.TAG}**`)
      } else
      if (oldUser.username.includes(x) && !newUser.username.includes(x)) { 
        !member.roles.cache.has(server.BOOST) 
        await member.roles.set(server.UNREGISTER).catch();
        await member.setNickname(`${conf.ikinciTag} İsim | Yaş`);
      member.send(`${guild.name} adlı sunucumuza olan erişim engeliniz kalktı. İsminizden (${x}) sembolünü kaldırarak sunucumuza erişim hakkı kazandınız. Keyifli Sohbetler**-Yönetim**`)
      }
  })
  })
};
  
module.exports.conf = {
  name: "userUpdate",
};
