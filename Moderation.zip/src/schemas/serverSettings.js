let mongoose = require("mongoose");
let Schema = mongoose.Schema;

let serverSettings = Schema({


BotOwner: {
    type: Array,
    default: []
},

guildID: {
    type: String,
    default: ""
},

BOTOWNER: {
    type: Array,
    default: []
},

TAG: {
    type: String,
    default: ""
},

TAG2: {
    type: String,
    default: ""
},

// Yetkiler
RoleManageAuth: {
    type: Array,
    default: []
},
BanAuth: {
  type: Array,
  default: []
},

JailAuth: {
  type: Array,
  default: []
},

REGISTERAuthorized: {
    type: Array,
    default: []
},

MuteAuth: {
type: Array,
default: []
},

VIPAuth: {
  type: Array,
  default: []
},

ReklamAuth: {
 type: Array,
 default: []
},

VMuteAuth: {
type: Array,
default: []
},

EnAltYetkiliRol: {
    type: Array,
    default: []
},

//Limitler
BanLIMIT: {
  type: Array,
  default: []
},

AGELIMIT: {
  type: Array,
  default: ""
}, 

JailLIMIT: {
 type: Array,
 default: ""
},

MuteLIMIT: {
 type: Array,
 default: ""
},

ReklamLIMIT: {
type: Array,
default: ""
},
//XD
ONEMONTH: {
type: Array,
default: ""
},

THREEMONTH: {
type: Array,
default: ""
},

SIXMONTH: {
type: Array,
default: ""
},

NINEMONTH: {
type: Array,
 default: "" 
},
ONEYEAR: {
 type: Array,
 default: ""
},

//Roller
SORUNCOZUCU: {
 type: Array,
 default: ""
},

MUZISYEN: {
type: Array,
default: ""
},

STREAMER: {
  type: Array,
  default: "" 
},

StreamerSorumlusu: {
  type: Array,
  default: ""
},

TERAPIST: {
type: Array,
default: ""
},

VIP: {
  type: Array,
  default: ""
},

MAN: {
    type: Array,
    default: []
},

WOMAN: {
    type: Array,
    default: []
},

UNREGISTER: {
    type: Array,
    default: []
},

ETK: {
  type: Array,
  default: ""
},

ÇEK: {
  type: Array,
  default: ""
},

BOOST: {
    type: Array,
    default: []
},

UYARI: {
 type: Array,
 default: ""
},

MAZERETLI: {
  type: Array,
  default: ""
},

KATILDI: {
type: Array,
default: ""
},

MUTED: {
    type: Array,
    default: []
},

VMUTED: {
    type: Array,
    default: []
},

BANTAG: {
    type: Array,
    default: []
},

REKLAM: {
 type: Array,
 default: []
},

SUPHELI: {
    type: Array,
    default: []
},

TEAM: {
    type: Array,
    default: []
},

BANNEDTAG: {
 type: Array,
 default: ""
},

LGBT: {
type: Array,
default: ""
},

SEVVAR: {
 type: Array,
 default: ""
},

SEVYOK: {
 type: Array,
 default: ""
},

SEVYAPM: {
 type: Array,
 default: ""
},

DC: {
 type: Array,
 default: ""
},

VK: {
 type: Array,
 default: ""
},

DCAuthor: {
 type: Array,
 default: []
},

VKAuthor: {
    type: Array,
    default: []
},

JAIL: {
    type: Array,
    default: []
},

VKCEZALI: {
    type: Array,
    default: []
},

DCCEZALI: {
    type: Array,
    default: []
},

STCEZALI: {
    type: Array,
    default: []
},


// CHANNEL

CHAT: {
    type: String,
    default: ""
},

REGISTER: {
    type: String,
    default: ""
},

INVITE: {
type: String,
default: ""
},

PUBCATEGORY: {
    type: Array,
    default: []
  },

toplantiSesChannel: {
    type: Array,
    default: ""
  },
  
TAGLOG: {
    type: String,
    default: ""
},

RULES: {
    type: String,
    default: ""
}
})


module.exports = mongoose.model("kurulum", serverSettings);
