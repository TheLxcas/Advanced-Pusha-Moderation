const { red } = require("../../configs/emojis.json")
module.exports = {
  conf: {
    aliases: [],
    name: "yaz"
  },

  run: async (client, message, args) => {
    let server = await serverSettings.findOne({
      guildID: message.guild.id
  });
    if(!server.BotOwner.includes(message.author.id)) return
    if(!args[0]) return message.react(red)
    message.delete();
    message.channel.send(args.join(' '));
  },
};

  
