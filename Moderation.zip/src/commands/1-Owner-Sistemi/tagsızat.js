const { MessageEmbed } = require("discord.js");
let serverSettings = require("../../schemas/serverSettings")
module.exports = {
conf:{
aliases: ["tagsızat"],
name: "tagsızat",
help: "tagsızat"
},
run: async(client, message, args) => {
    if (!message.member.hasPermission("ADMINISTRATOR")) return;

    let embed = new MessageEmbed().setColor('RANDOM').setTimestamp().setFooter(`Created By lucas`)
    let data = await sunucuayar.findOne({ guildID: message.guild.id });
    
    let tag = data.TAG;
    let boosterRol = data.BOOST;
    let kayıtsızRol = data.UNREGISTER;
   
    message.guild.members.cache.filter(s => !s.user.username.includes(tag) && !s.roles.cache.has(boosterRol) && !s.roles &&
 !s.roles.cache.has(kayıtsızRol)).forEach(async(member) => {
        setTimeout(async() => {
            member.roles.set([kayıtsızRol])
        }, 1000)
    })
    message.channel.send(embed.setDescription(`Kullanıcı adında tag bulunmayan kullanıcılar kayıtsıza atılıyor.`))

 },
};
