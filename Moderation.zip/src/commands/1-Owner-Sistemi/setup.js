const {
    MessageEmbed,
    Discord
} = require("discord.js");
const conf = client.ayarlar
const { red , green } = require("../../configs/emojis.json")
let mongoose = require("mongoose");
let sunucuayar = require("../../schemas/sunucuSettings");
module.exports.run = async (client, message, args, durum, kanal) => {
	if (!message.guild) return;
    
    if (message.guild.owner.id === message.author.id || this.client.config.sahip.some(member => message.author.id === member) || durum) {

        let sec = args[0]
        let embed = new MessageEmbed()
            .setColor("RANDOM")
            .setAuthor(message.author.tag, message.author.avatarURL({
                dynamic: true
            }))
            .setFooter(conf.footer)
            .setTimestamp()
           .setDescription(
      `\`\`\`SERVER SETUP\`\`\`\`
${this.client.config.prefix[0]}setup tag <serverTAG>\` (${server.TAG ? server.TAG : "\`YOK\`"})
${this.client.config.prefix[0]}setup tag2 <serverTAG>2\` (${server.TAG2 ? server.TAG2 : "\`YOK\`"})
${this.client.config.prefix[0]}setup botowner <BotOwner>\` (${server.BotOwner.length > 0 ? `${server.BotOwner.map(x => `<@${x}>`).join(",")}` : "\`YOK\`"})
            `)

        await sunucuayar.findOne({guildID: conf.sunucuId}, async (err, data) => {
            if (err) console.log(err)


            if (["TAG", "tag", "Tag"].some(y => y === sec)) {
                let select = args[1];
                if (!select) return message.react(red)
                data.TAG = select, data.save(), message.react(green)
            };
            if (["TAG2", "tag2", "Tag2"].some(y => y === sec)) {
                let select = args[1];
                if (!select) return message.react(red)
                data.TAG2 = select, data.save(), message.react(green)
            };
            if (["owner", "botOwner", "Owner", "own", "OWNER"].some(y => y === sec)) {
              let select = args[1];
              if (!select) return message.react(red)
              data.BOTOWNER = select, data.save(), message.react(green)
            };
            if (["rolverici","rolemanager"].some(y => y === sec)) {
              let select = args[1];
              if (!select) return message.react(red)
              data.RoleManageAuth = select, data.save(), message.react(green)
            };
            if (["streamersorumlusu"].some(y => y === sec)) {
              let select = args[1];
              if (!select) return message.react(red)
              data.StreamerSorumlusu = select, data.save(), message.react(green)
            };
            if (["streamer"].some(y => y === sec)) {
              let select = args[1];
              if (!select) return message.react(red)
              data.STREAMER = select, data.save(), message.react(green)
            };
            if (["soruncozucu"].some(y => y === sec)) {
              let select = args[1];
              if (!select) return message.react(red)
              data.SORUNCOZUCU = select, data.save(), message.react(green)
            };
            if (["sohbet-kanal", "chat", "sohbetkanal", "genelchat"].some(y => y === sec)) {
                let select = message.mentions.channels.first();
                if (!select) return message.react(red)
                data.CHAT = select.id, await data.save(), message.react(green)
            };
            if (["register-kanal", "register", "registerchat", "register-chat"].some(y => y === sec)) {
                let select = message.mentions.channels.first();
                if (!select) return message.react(red)
                data.REGISTER = select.id, await data.save(), message.react(green)
            }
            if (["taglog-kanal", "taglog", "tagbilgi", "Taglog"].some(y => y === sec)) {
                let select = message.mentions.channels.first();
                if (!select) return message.react(red)
                data.TAGLOG = select.id, await data.save(), message.react(green)
            };
            if (["kurallar-kanal", "kurallar", "kurallarkanal", "kurallarchat", "rules", "rule"].some(y => y === sec)) {
                let select = message.mentions.channels.first();
                if (!select) return message.react(red)
                data.RULES = select.id, await data.save(), message.react(green)
            };
             if (["vkyonetici", "vkyönetici", "vk-yönetici", "vampirköylü"].some(y => y === sec)) {
                let select = message.mentions.roles.first();
                if (!select) return message.react(red)
                data.VKAuthor = select.id, await data.save(), message.react(green)
            };
            if (["dcyonetici", "dcyönetici", "dc-yönetici", "doğrulukcesaretlik"].some(y => y === sec)) {
              let select = message.mentions.roles.first();
              if (!select) return message.react(red)
              data.DCAuthor = select.id, await data.save(), message.react(green)
            };
            if (["müzisyen"].some(y => y === sec)) {
              let select = message.mentions.roles.first();
              if (!select) return message.react(red)
              data.MUZISYEN = select.id, await data.save(), message.react(green)
            };
            if (["erkek", "Erkek", "erkekROL", "man", "Man"].some(y => y === sec)) {
                let select;
                if (message.mentions.roles.size >= 1) {
                    select = message.mentions.roles.map(r => r.id);
                } else {
                    if (!select) return message.react(red)
                    select = args.splice(0, 1).map(id => message.guild.roles.cache.get(id)).filter(r => r != undefined);
                }
                data.MAN = select, await data.save(), message.react(green)
            };
            if (["kadın", "kız", "kızROL", "kadınROL", "woman"].some(y => y === sec)) {
                let select;
                if (message.mentions.roles.size >= 1) {
                    select = message.mentions.roles.map(r => r.id);
                } else {
                    if (!select) return message.react(red)
                    select = args.splice(0, 1).map(id => message.guild.roles.cache.get(id)).filter(r => r != undefined);
                }
                data.WOMAN = select, await data.save(), message.react(green)
            };
            if (["kayıtsız", "unregister", "kayıtsızüye", "uregister", "kayitsiz"].some(y => y === sec)) {
                let select;
                if (message.mentions.roles.size >= 1) {
                    select = message.mentions.roles.map(r => r.id);
                } else {
                    if (!select) return message.react(red)
                    select = args.splice(0, 1).map(id => message.guild.roles.cache.get(id)).filter(r => r != undefined);
                }
                data.UNREGISTER = select, await data.save(), message.react(green)
            };
            if (["ekip", "teamrol", "ekiprol", "taglırol", "taglı", "team", "takım"].some(y => y === sec)) {
                let select = message.mentions.roles.first();
                if (!select) return message.react(red)
                data.TEAM = select.id, await data.save(), message.react(green)
            };
            if (["boost", "booster", "boostrol", "boosterrol"].some(y => y === sec)) {
                let select = message.mentions.roles.first();
                if (!select) return message.react(red)
                data.BOOST = select.id, await data.save(), message.react(green)
            };
            if (["jail", "jailed", "cezalı", "Jail", "Jailed", "Cezalı"].some(y => y === sec)) {
                let select = message.mentions.roles.first();
                if (!select) return message.react(red)
                data.JAIL = select.id, await data.save(), message.react(green)
            };
            if (["mute", "muted", "Mute", "Muted"].some(y => y === sec)) {
                let select = message.mentions.roles.first();
                if (!select) return message.react(red)
                data.MUTED = select.id, await data.save(), message.react(green)
            };
            if (["etk", "etkinlikk", "ETKİNLİK", "etkinlikkatılımcı"].some(y => y === sec)) {
              let select = message.mentions.roles.first();
              if (!select) return message.react(red)
              data.ETK = select.id, await data.save(), message.react(green)
            };
            if (["çek", "çekilişk", "ÇEKİLİŞ", "çekilişkatılmcı"].some(y => y === sec)) {
              let select = message.mentions.roles.first();
              if (!select) return message.react(red)
              data.ÇEK = select.id, await data.save(), message.react(green)
            };
            if (["vmute", "vmuted", "VMute", "VMuted", "VoiceMute", "sesmute", "SesMute", "Sesmute"].some(y => y === sec)) {
                let select = message.mentions.roles.first();
                if (!select) return message.react(red)
                data.VMUTED = select.id, await data.save(), message.react(green)
            };
            if (["yasaklıtag", "yasaklıtagrol", "bantag", "ban-tag", "yasaklı-tag", "ytag"].some(y => y === sec)) {
                let select = message.mentions.roles.first();
                if (!select) return message.react(red)
                data.BANTAG = select.id, await data.save(), message.react(green)
            };
            if (["şüpheli", "supheli", "şüphelihesap", "suphelihesap", "Şüpheli", "Supheli"].some(y => y === sec)) {
                let select = message.mentions.roles.first();
                if (!select) return message.react(red)
                data.SUPHELI = select.id, await data.save(), message.react(green)
            };
            if (["enaltyetkilirol", "en-alt-yetkili-rol", "enaltrol"].some(y => y === sec)) {
                let select = message.mentions.roles.first();
                if (!select) return message.react(red)
                data.EnAltYetkiliRol = select.id, await data.save(), message.react(green)
            };
            if (["kayıtsorumlusu", "kayit-sorumlusu", "kayıt-sorumlusu", "registerauthorized", "Kayıtçı", "kayitci"].some(y => y === sec)) {
                let select;
                if (message.mentions.roles.size >= 1) {
                    select = message.mentions.roles.map(r => r.id);
                } else {
                    if (!select) return message.react(red)
                    select = args.splice(0, 1).map(id => message.guild.roles.cache.get(id)).filter(r => r != undefined);
                }
                data.REGISTERAuthorized = select, await data.save(), message.react(green)
            };
            if (["vkcezalı"].some(y => y === sec)) {
                let select = message.mentions.roles.first();
                if (!select) return message.react(red)
                data.VKCEZALI = select.id, await data.save(), message.react(green)
            };
            if (["dccezalı"].some(y => y === sec)) {
                let select = message.mentions.roles.first();
                if (!select) return message.react(red)
                data.DCCEZALI = select.id, await data.save(), message.react(green)
            };
            if (["stcezalı"].some(y => y === sec)) {
                let select = message.mentions.roles.first();
                if (!select) return message.react(red)
                data.STCEZALI = select.id, await data.save(), message.react(green)
            };
            if (["yardım", "Yardım", "help", "Help"].some(y => y === sec)) {
                return message.channel.send(embed);
            };
            if (!sec) {
                return message.channel.send(embed);
            };

        });

    } else return client.Embed(message.channel.id, `Bu komutu kullanabilmek için Sunucu Sahibi - Bot Sahibi olmalısın!`);
}
exports.conf = {aliases: ["kurulum", "kur", "Setup", "SETUP", "Setup"]}
exports.help = {name: 'setup'}
function removeItemOnce(arr, value) { var index = arr.indexOf(value); if (index > -1) { arr.splice(index, 1); } return arr; }
