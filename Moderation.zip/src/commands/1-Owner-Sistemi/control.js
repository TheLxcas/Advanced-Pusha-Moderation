const disbut = require("discord-buttons");
const { MessageEmbed } = require("discord.js");
const { star, kirmiziok } = require("../../configs/emojis.json")
let ayar = require("../../schemas/serverSettings");
const moment = require("moment");
require("moment-duration-format");

module.exports = {
    conf: {
      aliases: ["control"],
      name: "control",
      help: "control"
    },
  
    run: async (client, message, args, durum, kanal) => {

        if (message.member.permissions.has(8)) {
let data = await serverSettings.findOne({
  guildID: message.guild.id
});
      let ekipRolu = data.TEAM;
      let etkinlik = data.ETK;
      let cekilis = data.ÇEK;
      let tag = data.TAG;
      let team = data.TEAM;
      let kayıtsız = data.UNREGISTER;
      
      
    let taglilar = message.guild.members.cache.filter(s => s.user.username.includes(tag) && !s.roles.cache.has(team))
    let et = message.guild.members.cache.filter(member => !member.roles.cache.has(cekilis) && !member.roles.cache.has(etkinlik)).size;
    let lucas = message.guild.members.cache.filter(m => m.roles.cache.filter(r => r.id !== message.guild.id).size == 0)

let ecdagit = new disbut.MessageButton().setStyle('red').setLabel('Etkinlik/Çekiliş Rol Dağıt').setID('ecdagit')
let tagrol = new disbut.MessageButton().setStyle('green').setLabel('Tag Rol Dağıt').setID('tagrol')
let kayıtsızdagit = new disbut.MessageButton().setStyle('blurple').setLabel('Kayıtsız Rol Dağıt').setID('kayıtsızdagit')

let embed = new MessageEmbed()
.setDescription(`
${message.member.toString()}, \`${moment(Date.now()).format("LLL")}\` tarihinden  itibaren \`${message.guild.name}\` rolü olmayan üyelerin rol dağıtım tablosu aşağıda belirtilmiştir.
`)

.addFields(
{ name: "__**Etkinlik/Çekiliş Rol**__", value: `
\`\`\`fix
${et} kişi
\`\`\`
`, inline: true },
{ name: "__**Taglı Rol**__", value: `
\`\`\`fix
${taglilar.size} kişi
\`\`\`
`, inline: true },
{ name: "__**Kayıtsız Rol**__", value: `
\`\`\`fix
${lucas.size} kişi
\`\`\`
`, inline: true }
)

.setColor("BLACK")
.setFooter(message.author.tag, message.author.avatarURL())
.setTimestamp()
.setThumbnail(message.author.displayAvatarURL({ dynamic: true, size: 2048 }))

message.channel.send(embed, { buttons: [ecdagit,tagrol,kayıtsızdagit] })

}

client.on('clickButton', async (button) => {

    if (button.id === 'ecdagit') {

      let etkinlik = data.ETK;
      let cekilis = data.ÇEK

    let lucas = message.guild.members.cache.filter(member => !member.roles.cache.has(etkinlik) && !member.roles.cache.has(cekilis))
    button.reply.send(`
Etkinlik/Çekiliş rolü olmayan ${lucas.size} kullanıcıya etkinlik, çekiliş rolleri verildi !

Etkinlik/Çekiliş rolü verilen kullanıcılar;
${lucas.map(x => x || "Rolü olmayan Kullanıcı bulunmamaktadır.")}`)
        message.guild.members.cache.filter(member => !member.roles.cache.has(etkinlik) && !member.roles.cache.has(cekilis)).map(x=> x.roles.add(cekilis, etkinlik));
    }


    if (button.id === 'tagrol') {
      let taglilar = message.guild.members.cache.filter(s => s.user.username.includes(tag) && !s.roles.cache.has(team))

    button.reply.send(`
Tagı olup rolü olmayan ${taglilar.size} kullanıcıya rol verildi.

Tag Rolü verilen kullanıcılar;
${taglilar.map(x => x || "Rolü olmayan Kullanıcı bulunmamaktadır.")}`)

    message.guild.members.cache.filter(s => s.user.username.includes(tag) && !s.roles.cache.has(team)).map(x=> x.roles.add(team))                
    }

    if (button.id === 'kayıtsızdagit') {
    let lucas = message.guild.members.cache.filter(m => m.roles.cache.filter(r => r.id !== message.guild.id).size == 0)

    button.reply.send(`
Kayıtsız rolü olmayan ${lucas.size} kullanıcıya kayıtsız rolü verildi !

Kayıtsız Rolü verilen kullanıcılar;
${lucas.map(x => x || "Rolü olmayan Kullanıcı bulunmamaktadır.")} `)

    message.guild.members.cache.filter(m => m.roles.cache.filter(r => r.id !== message.guild.id).size == 0).map(x=> x.roles.add(kayıtsız))

    }

  });
}
}
