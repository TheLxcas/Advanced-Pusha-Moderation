const { red , green} = require("../../configs/emojis.json")
const conf = require("../../schemas/serverSettings")
module.exports = {
  conf: {
    aliases: ["musician","Muzisyen"],
    name: "Musician",
    help: "Musician",
  },

  run: async (client, message, args, embed, prefix) => {
    let data = await serverSettings.findOne({ guildID: message.guild.id });
if (!message.member.hasPermission("ADMINISTRATOR") &&  !data.RoleManageAuth.some(x => message.member.roles.cache.has(x))) { message.channel.send("Yeterli yetkin bulunmuyor!").then(x=>x.delete({timeout:5000}))
message.react(red)
return }
let musician = data.MUZISYEN;

const user =message.mentions.members.first() || message.guild.members.cache.get(args[0]);
if (!user) { message.channel.send( "Böyle bir kullanıcı bulunamadı!").then(x=>x.delete({timeout:5000}))
message.react(red)
return }
if(!user.roles.cache.has(musician)) 
{
user.roles.add(musician)
message.lineReply(`${green} Başarılı! ${user} kişisine başarılı bir şekilde \`Musician\` rolü verildi!`).then(x=>x.delete({timeout:5000}))
} else {
user.roles.remove(musician)
message.lineReply(`${green} Başarılı! ${user} kişisinden başarılı bir şekilde \`Musician\` rolü alındı!`).then(x=>x.delete({timeout:5000}))
}
}
};
