const Discord = require("discord.js");
;
const conf = require("../../schemas/serverSettings")

module.exports = {
  conf: {
    aliases: [],
    name: "rolsuz",
    owner: true,
  },

  run: async (client, message, args, embed) => {
    let data = await sunucuayar.findOne({ guildID: message.guild.id });
    
    let kayıtsız = data.UNREGISTER;
    
    let lucas = message.guild.members.cache.filter(m => m.roles.cache.filter(r => r.id !== message.guild.id).size == 0)
    if(args[0] == "ver") {
      lucas.forEach(r => {
    r.roles.add(kayıtsız)
    })
    message.channel.send(embed
    .setDescription("Sunucuda rolü olmayan \`"+ lucas.size +"\` kişiye kayıtsız rolü verildi!"))
    } else if(!args[0]) {
    message.channel.send(embed
    .setDescription("Sunucumuzda rolü olmayan \`"+ lucas.size +"\` kişi var. Bu kişilere kayıtsız rolü vermek için \`.rolsüz ver\` komutunu uygulayın!"))    
}
  },
};
 
