const { MessageEmbed, Discord } = require('discord.js');
const { MessageButton, MessageActionRow } = require('discord-buttons');

module.exports = {
    conf: {
      aliases: ["log-kur"],
      name: "log-kur",
      help: "log-kur"
    },

    run: async (client, message, args, embed) => {
let member = message.guild.member(message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.author);

    var button_1 = new MessageButton()
    .setID("Kur")
    .setLabel("Log kur 1")
    .setStyle("blurple")
  
   var button_2 = new MessageButton()
    .setID("Kur2")
    .setLabel("Log kur 2")
    .setStyle("blurple")
    
    var button_3 = new MessageButton()
    .setID("Kur3")
    .setLabel("Log kur 3")
    .setStyle("blurple")
    
    var button_4 = new MessageButton()
    .setID("İptal")
    .setLabel("iptal")
    .setStyle("red")

    var row = new MessageActionRow()
    .addComponent(button_1)
    .addComponent(button_2)
    .addComponent(button_3)
    .addComponent(button_4)
    
let server = await serverSettings.findOne({ guildID: message.guild.id }); if(!server.BotOwner.includes(message.author.id)) return message.channel.send(
new Discord.MessageEmbed().setThumbnail(message.author.avatarURL())
.setColor('#330066')
.setAuthor(member.user.tag, member.user.avatarURL({ dynamic: true }))
.setDescription(`• \`.log-kur\` **kullanmak için,** \`Bot Owner\` **olmanız gerekiyor.**`)
.addField('Sunucu Sahibi', message.guild.owner.user.tag));

let lucas = new MessageEmbed()
.setDescription(`log kurulumunu başlatmak için lütfen 30 saniye içerisinde 
\`\`\`Moderasyon Log : "Log Kur 1"
Buttona Tıklamanız,
Guard Log : "Log Kur 2"
Buttona Tıklamanız,
Logger Log : "Log Kur 3" Buttona Tıklamanız Yeter\`\`\`
**Botun Rolünün En Üstte Olduğundan Emin Olunuz !**`)
.setColor('#330066')
.setAuthor(member.user.tag, member.user.avatarURL({ dynamic: true }))
.setFooter(`Developed By lucas | Ping: ${client.ws.ping.toFixed(0)}`, member.user.avatarURL({ dynamic: true }))
 let msg = await message.channel.send({ components : [ row ], embed: lucas})
    var filter = (button) => button.clicker.user.id === message.author.id;
   
    let collector = await msg.createButtonCollector(filter, { time: 30000 })

      collector.on("collect", async (button) => {
        if(button.id === "Kur") {

message.guild.channels.create('Lucas Moderation Log', {type: 'category'}).then(parent => {
message.guild.channels.create('ban-log', {type: 'text'}).then(c => c.setParent(parent.id));
message.guild.channels.create('mute-log', {type: 'text'}).then(c => c.setParent(parent.id));
message.guild.channels.create('vmute-log', {type: 'text'}).then(c => c.setParent(parent.id));
message.guild.channels.create('jail-log', {type: 'text'}).then(c => c.setParent(parent.id));
message.guild.channels.create('yetki-log', {type: 'text'}).then(c => c.setParent(parent.id));
message.guild.channels.create('yasaklı-tag-log', {type: 'text'}).then(c => c.setParent(parent.id));
message.guild.channels.create('komut-log', {type: 'text'}).then(c => c.setParent(parent.id));
message.guild.channels.create('market-log', {type: 'text'}).then(c => c.setParent(parent.id));
message.guild.channels.create('ekip-log', {type: 'text'}).then(c => c.setParent(parent.id));
message.guild.channels.create('voice-log', {type: 'text'}).then(c => c.setParent(parent.id));
message.guild.channels.create('rol-log', {type: 'text'}).then(c => c.setParent(parent.id));
message.guild.channels.create('mazeretli-log', {type: 'text'}).then(c => c.setParent(parent.id));
message.guild.channels.create('rank-log', {type: 'text'}).then(c => c.setParent(parent.id));
});

message.channel.send(`Bot loglarının kurulumu başarıyla tamamlanmıştır.`)
}
 if(button.id === "Kur2") {
message.guild.channels.create('Lucas Guard Log', {type: 'category'}).then(parent => {
message.guild.channels.create('sekme-guard', {type: 'text'}).then(c => c.setParent(parent.id));
message.guild.channels.create('sekme-tarayici', {type: 'text'}).then(c => c.setParent(parent.id));
      });
message.guild.channels.create('backup', { type: 'text' }).then(c => c.setParent(parent.id));
message.guild.channels.create('chat-guard', { type: 'text' }).then(c => c.setParent(parent.id));
message.guild.channels.create('genel-guard', {type: 'text'}).then(c => c.setParent(parent.id));
message.guild.channels.create('sunucu-guard', {type: 'text'}).then(c => c.setParent(parent.id));
message.guild.channels.create('user-guard', {type: 'text'}).then(c => c.setParent(parent.id));
message.channel.send(`Bot loglarının kurulumu başarıyla tamamlanmıştır.`)
  }

if(button.id === "Kur3") {

  message.guild.channels.create('Lucas Logger Log', {type: 'category'}).then(parent => {
message.guild.channels.create('mesaj_silme_log', {type: 'text'}).then(c => c.setParent(parent.id));
message.guild.channels.create('mesaj_edit_log', {type: 'text'}).then(c => c.setParent(parent.id));
message.guild.channels.create('ses_basit_log', {type: 'text'}).then(c => c.setParent(parent.id));
message.guild.channels.create('ses_mic_log', {type: 'text'}).then(c => c.setParent(parent.id));
message.guild.channels.create('ses_log', {type: 'text'}).then(c => c.setParent(parent.id));
message.guild.channels.create('join_leave_basit_log', {type: 'text'}).then(c => c.setParent(parent.id));
  });
  message.guild.channels.create('join_leave_log', {type: 'text'}).then(c => c.setParent(parent.id));
  message.guild.channels.create('nickname_log', {type: 'text'}).then(c => c.setParent(parent.id));
  message.guild.channels.create('rol_log', {type: 'text'}).then(c => c.setParent(parent.id));
  message.guild.channels.create('webhook_log', {type: 'text'}).then(c => c.setParent(parent.id));
  message.guild.channels.create('sunucu_update_log', {type: 'text'}).then(c => c.setParent(parent.id));
  message.guild.channels.create('kanal_oluşturma_log', {type: 'text'}).then(c => c.setParent(parent.id));  
  message.guild.channels.create('kanal_update_log', {type: 'text'}).then(c => c.setParent(parent.id));
  message.guild.channels.create('kanal_silme_log', {type: 'text'}).then(c => c.setParent(parent.id));
  message.guild.channels.create('ban_atma_log', {type: 'text'}).then(c => c.setParent(parent.id));
  message.guild.channels.create('ban_kaldırma_log', {type: 'text'}).then(c => c.setParent(parent.id));
  message.guild.channels.create('bot_ekleme_log', {type: 'text'}).then(c => c.setParent(parent.id)); 
    message.guild.channels.create('rol_log', {type: 'text'}).then(c => c.setParent(parent.id));
      message.guild.channels.create('rol_log_basit', {type: 'text'}).then(c => c.setParent(parent.id));
  message.guild.channels.create('rol_oluşturma_log', {type: 'text'}).then(c => c.setParent(parent.id));
  message.guild.channels.create('rol_güncelleme_log', {type: 'text'}).then(c => c.setParent(parent.id));
  message.guild.channels.create('rol_silme_log', {type: 'text'}).then(c => c.setParent(parent.id));
  message.guild.channels.create('webhook', {type: 'text'}).then(c => c.setParent(parent.id));
    message.guild.channels.create('emoji_olusturma_log', {type: 'text'}).then(c => c.setParent(parent.id));
    message.guild.channels.create('guild_log', {type: 'text'}).then(c => c.setParent(parent.id));
  message.guild.channels.create('emoji_güncelleme_log', {type: 'text'}).then(c => c.setParent(parent.id));
  message.guild.channels.create('emoji_silme_log', {type: 'text'}).then(c => c.setParent(parent.id));
  message.channel.send(`Bot loglarının kurulumu başarıyla tamamlanmıştır.`)
  }

if(button.id === "İptal") {
msg.delete();
await button.think(true);
await button.reply.edit(`${button.clicker.member} Başarıyla Sunucu Kurma İşlemi İptal Edilmiştir!`)
}

})
}};
