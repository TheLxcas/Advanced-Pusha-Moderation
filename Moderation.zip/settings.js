const config = {

token: "",
botses: "",
botDurum: "",
prefix: [".","!"],
guildID: "",
sahip: "658237777309204491",
mongoUrl: "",
dmMessages: false,

messageDolar: 1,
voiceDolar: 1,


messageCount: 1,
messageCoin: 2,
voiceCount: 1,
voiceCoin: 4,
publicCoin: 4,
inviteCount: 1,
inviteCoin: 15,
taggedCoin: 25,
toplamsCoin: 5.5,
yetkiCoin: 30,
}

module.exports = config;
